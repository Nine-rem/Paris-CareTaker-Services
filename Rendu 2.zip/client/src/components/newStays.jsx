import React from 'react';

function NewStays() {
  return (
    <>
    <div>
      <div id="new-stays" className="box centered-text">
        <h2>Nos nouveautés</h2>
      </div>
    </div>
    </>
  );
}

export default NewStays;
