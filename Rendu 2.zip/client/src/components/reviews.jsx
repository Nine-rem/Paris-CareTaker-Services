import React from 'react';

function Reviews() {
  return (
    <>
    <div>  
      <div id="reviews" className="box centered-text">
        <h2>Ce qu'ils pensent de nous</h2>
      </div>
    </div>
    </>
  );
}

export default Reviews;
