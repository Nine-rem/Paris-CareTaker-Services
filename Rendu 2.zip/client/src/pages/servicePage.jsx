import React from "react";


export default function ServicePage() {
    return (
        <>
            <div id="service" className="box">
                <h2>Nos services</h2>
                <div className="row">
                    <div className="col-md-4">
                        <h3>Service 1</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam et nisi ac quam ultrices.</p>
                    </div>
                    <div className="col-md-4">
                        <h3>Service 2</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam et nisi ac quam ultrices.</p>
                    </div>
                    <div className="col-md-4">
                        <h3>Service 3</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam et nisi ac quam ultrices.</p>
                    </div>
                </div>
            </div>
        </>
    )
}