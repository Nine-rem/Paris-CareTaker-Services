import React from "react";

export default function ContactPage() {
    return (
        <>
            <div id="contact" className="box">
                <h2>Contact</h2>
                <p>Vous pouvez nous contacter par téléphone au 01 23 45 67 89 ou par mail à l'adresse pcs@gmail.com.</p>
            </div>
        </>
    )
}