import React from "react";

export default function QuotationPage() {
    return (
        <>
            <div id="quotation" className="box">
                <h2>Devis</h2>
                <p>Vous pouvez demander un devis en remplissant le formulaire ci-dessous.</p>
            </div>
        </>
    )
}
