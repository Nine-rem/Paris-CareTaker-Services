Pour utiliser nodejs

1)Installer npm

2)npm install yarn


Paquets a installer dans api

1)npm install nodejs

2)npm install nodemon

3)npm install express mysql body-parser bcryptjs jsonwebtoken

4)npm install cookie-parser


Pour mettre en route l'api

nodemon index.js


Pour utiliser react

yarn add bootstrap

yarn dev 
