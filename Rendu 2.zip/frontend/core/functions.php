<?php

// Comparaison des villes des biens (pour affichage trié)
function compareCity($stay1, $stay2) {
    return strcmp($stay1['ville_agence'], $stay1['ville_agence']);
}