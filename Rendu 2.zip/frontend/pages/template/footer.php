		<footer class="py-3 my-4">
			<ul class="nav justify-content-center border-bottom pb-3 mb-3">
				<li class="nav-item"><a href="../pages/" class="nav-link px-2">Accueil</a></li>
				<li class="nav-item"><a href="../pages/stay-all.php" class="nav-link px-2">Logement</a></li>
				<li class="nav-item"><a href="#" class="nav-link px-2">Service</a></li>
				<li class="nav-item"><a href="#" class="nav-link px-2">Devis</a></li>
				<li class="nav-item"><a href="../pages/legal.php" class="nav-link px-2">Mentions légales</a></li>
				<li class="nav-item"><a href="#" class="nav-link px-2">Cookies</a></li>
				<li class="nav-item"><a href="../pages/service-terms.php" class="nav-link px-2">Conditions générales</a></li>
				<li class="nav-item"><a href="../pages/contact.php" class="nav-link px-2">Contact</a></li>
			</ul>
			<p class="text-center">© 2024 PCS | Tous droits réservés</p>
		</footer>

		<script src="script.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
	</body>
</html>