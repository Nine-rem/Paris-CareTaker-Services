<?php include "template/header.php";?>

<div class="box container">
    <div class="row justify-content-center">
        <div class="col">
            <div class="text-center">
                <img src="../assets/images/error.png" class="img-fluid" width="500px">
                <h1 style="font-size: 2rem; font-weight: 600;">Oops, une erreur s'est produite !</h1>
            </div>
        </div>
    </div>
</div>

<?php include "template/footer.php";?>